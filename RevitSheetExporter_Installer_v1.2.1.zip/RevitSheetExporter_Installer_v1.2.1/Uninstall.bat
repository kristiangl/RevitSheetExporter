@echo off
setlocal enabledelayedexpansion
title Revit Sheet Exporter -- Uninstaller

echo.
echo  ================================================
echo   Revit Sheet Exporter -- Uninstaller
echo  ================================================
echo.

set "ADDINS=%APPDATA%\Autodesk\Revit\Addins"
set "REMOVED=0"

for %%V in (2026 2027) do (
    if exist "%ADDINS%\%%V\RevitSheetExporter.dll" (
        del /F /Q "%ADDINS%\%%V\RevitSheetExporter.dll"
        del /F /Q "%ADDINS%\%%V\RevitSheetExporter.addin"
        echo  [+] Removed from Revit %%V addins folder
        set "REMOVED=1"
    ) else (
        echo  [ ] Not installed for Revit %%V -- skipping
    )
)

echo.

if "!REMOVED!"=="1" (
    echo  Done! Changes take effect next time Revit starts.
) else (
    echo  Nothing to remove.
)

echo.
pause

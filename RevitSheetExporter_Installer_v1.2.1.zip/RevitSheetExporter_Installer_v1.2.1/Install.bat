@echo off
setlocal enabledelayedexpansion
title Revit Sheet Exporter -- Installer

echo.
echo  ================================================
echo   Revit Sheet Exporter -- Installer
echo  ================================================
echo.

set "ADDINS=%APPDATA%\Autodesk\Revit\Addins"
set "INSTALLED=0"

:: Revit 2026
if exist "C:\Program Files\Autodesk\Revit 2026\Revit.exe" (
    echo  [+] Revit 2026 found
    mkdir "%ADDINS%\2026" 2>nul
    copy /Y "2026\RevitSheetExporter.dll"   "%ADDINS%\2026\" >nul
    copy /Y "2026\RevitSheetExporter.addin" "%ADDINS%\2026\" >nul
    echo      Installed to: %ADDINS%\2026\
    set "INSTALLED=1"
) else (
    echo  [ ] Revit 2026 not found -- skipping
)

echo.

:: Revit 2027
if exist "C:\Program Files\Autodesk\Revit 2027\Revit.exe" (
    echo  [+] Revit 2027 found
    mkdir "%ADDINS%\2027" 2>nul
    copy /Y "2027\RevitSheetExporter.dll"   "%ADDINS%\2027\" >nul
    copy /Y "2027\RevitSheetExporter.addin" "%ADDINS%\2027\" >nul
    echo      Installed to: %ADDINS%\2027\
    set "INSTALLED=1"
) else (
    echo  [ ] Revit 2027 not found -- skipping
)

echo.

if "!INSTALLED!"=="1" (
    echo  Done! Restart Revit and look for the "Sheet Exporter" tab.
) else (
    echo  No supported Revit installation found.
    echo  Supported versions: 2026, 2027
)

echo.
pause
